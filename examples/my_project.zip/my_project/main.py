import datetime

import numpy as np

import rand_gen
from shape import circle
from shape import rectangle


def get_current_date():
    return datetime.datetime.now()


def main():
    print("Current date:", get_current_date())
    print("A numpy ndarray", np.arange(10))
    print("A random integer", rand_gen.get_random_int())
    print("Area of circle: ", circle.get_area(5))
    print("Area of rectangle: ", rectangle.get_area(10, 5))


if __name__ == "__main__":
    main()
