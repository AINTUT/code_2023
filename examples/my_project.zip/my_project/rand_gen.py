import random


def get_random_int():
    return random.randint(10, 100)
