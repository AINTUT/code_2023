PI = 3.14159


def get_area(radius):
    return PI * radius * radius
