def get_area(width, height):
    return width * height * 0.5
