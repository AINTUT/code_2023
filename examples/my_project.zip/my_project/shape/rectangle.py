def get_area(width, height):
    return width * height
